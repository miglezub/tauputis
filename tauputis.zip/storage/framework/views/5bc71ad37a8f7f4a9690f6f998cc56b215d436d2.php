<?php $__env->startComponent('mail::message'); ?>
# <div class="text-success header">Mėnesinė ataskaita (<?php echo date("Y-m", strtotime('first day of last month')) ?>)</div>

Sveiki, <?php echo e($username); ?>.<br>
Paruošta jūsų praeito mėnesio ataskaita:  
<div class="container">
    <span>Išlaidos: <?php echo e($expenses); ?></span>
    <span class="float-right">Įplaukos: <?php echo e($income); ?></span>
    <div class="center">
        <?php if($income == 0 && $expenses == 0): ?>
            Per praeitą mėnesį nebuvo pridėta išlaidų ar įplaukų.
        <?php elseif($income == 0 && $expenses != 0): ?>
            Šį mėnesį nebuvo pridėta pajamų, išlaidos: <span class="text-danger"><?php echo e($expenses); ?></span>.
        <?php elseif($income != 0 && $expenses == 0): ?>
            Šį mėnesį nebuvo pridėta išlaidų, pajamos: <span class="text-success"><?php echo e($income); ?></span>.
        <?php elseif($income > $expenses): ?>
            Išlaidos sudaro <span class="text-success"><?php echo e(round($expenses/$income*100, 2)); ?>%</span> įplaukų.
        <?php else: ?>
            Išlaidos viršija įplaukas <span class="text-danger"><?php echo e(round($expenses/$income*100-100, 2)); ?>%</span>.
        <?php endif; ?>
    </div>
    <?php if(count($carts) > 0): ?>
        <hr class="text-success">
        Išlaidos, suskirstytos pagal kategorijų krepšelius:<br>
        <table id="cart-table" class="table">
            <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr><td><?php echo e($payment_types[$cart->fk_type]->name); ?></td><td><?php echo e($cart->last_month_value); ?></td></tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    <?php endif; ?>
</div>
<div class="center">Diagramas ir išsamesnę statistiką, rasite puslapyje.</div>
<?php $__env->startComponent('mail::button', ['url' => config('app.url'), 'color' => 'success']); ?>
Peržiūrėti puslapyje
<?php if (isset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e)): ?>
<?php $component = $__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e; ?>
<?php unset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<style>
    .header {
        font-size: 24px;
    }

    .center {
        text-align: center;
    }

    .text-success {
        color: #48bb78;
        font-weight: bold;
    }

    .text-danger {
        color: #FC175A;
        font-weight: bold;
    }

    .container {
        border: 1px solid #48bb78;
        font-size: 16px;
        border-radius: 4px;
        padding: 5px 10px;
    }

    .float-right {
        float: right;
    }

    .table {
        width: 70%; 
        margin: auto;
    }

    #cart-table>tr>td {
        border-bottom: 1px solid #48bb78;
    }
</style>
<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\laravel\tauputis\resources\views/emails/statsMonthly.blade.php ENDPATH**/ ?>