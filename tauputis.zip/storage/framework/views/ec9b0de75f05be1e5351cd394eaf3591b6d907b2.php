<?php $__env->startSection('title', 'Statistika'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">Statistika</div>
                <div class="card-body">
                    <div class="mt-2 mb-4">
                        <stats />
                    </div>
                    <div class="container h-100">
                        <line-chart-container :payment_types="<?php echo e($payment_types); ?>"></line-chart-container>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\tauputis\resources\views/stats/index.blade.php ENDPATH**/ ?>